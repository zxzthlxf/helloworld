# dbfcsv

Basic usage:

```
dbfcsv /path/to/dbffile.dbf
```

With headers and tab delimiter:

```
dbfcsv -d $'\t' -h /path/to/dbffile.dbf 
```

Resources:

* https://code.google.com/p/go-dbf/ (old)
* https://github.com/LindsayBradford/go-dbf
